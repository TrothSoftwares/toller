<?php
    /*
    Plugin Name: TollerApp
    Plugin URI: http://www.meembit.com
    Description: Plugin for implementing toller app functions
    Author: Mohammed Talha
    Version: 1.0
    Author URI: http://www.alfikri.in
    */

    // Removes from admin menu



    add_action( 'admin_menu', 'my_remove_admin_menus' );
    function my_remove_admin_menus() {
        remove_menu_page( 'edit-comments.php' );
    }
    // Removes from post and pages
    add_action('init', 'remove_comment_support', 100);

    function remove_comment_support() {
        remove_post_type_support( 'post', 'comments' );
        remove_post_type_support( 'page', 'comments' );
    }
    // Removes from admin bar
    function mytheme_admin_bar_render() {
        global $wp_admin_bar;
        $wp_admin_bar->remove_menu('comments');
    }
    add_action( 'wp_before_admin_bar_render', 'mytheme_admin_bar_render' );









function toller_admin() {
    include('toller.php');
}
function toller_admin_actions() {
    add_menu_page("Toller", "Toller" ,'read', "Toller", "toller_admin");
}
add_action('admin_menu', 'toller_admin_actions');

define('TOLLER_PLUGIN_URL', plugin_dir_url( __FILE__ ));


function timepicker(){
  wp_register_style('kv_js_time_style' , TOLLER_PLUGIN_URL. 'css/jquery.timepicker.css');
	wp_enqueue_style('kv_js_time_style');
  wp_enqueue_script('time-picker',TOLLER_PLUGIN_URL. 'js/jquery.timepicker.js');
}

add_action('admin_head', 'timepicker');





if(isset($_POST['Scheduleset1'])){
  // print_r($_POST);
  // exit;

   $serializedpost =  serialize($_POST);
   $my_post = array(
       'ID'           => $_POST['postid'],
       'post_content' => $serializedpost,
   );

 // Update the post into the database
   wp_update_post( $my_post );
  //  $serializedpost =  serialize($_POST);



}
